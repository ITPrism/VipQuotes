Vip Quotes for Joomla! 
==========================
( Version 2.2 )
--------------------------

Changelog
---------

v2.2
---------
* Improved

v2.1
---------
* [[#1]](https://github.com/ITPrism/VipQuotes/issues/1 "Impossible to create a New Category") Fixed the bug with ability to create categories.
* Improved

v2.0
---------
* Refactored and ported to Joomla! 2.5

v1.6
---------
* Fixed bugs

v1.5
---------
* Now you can create a view with categories.
* SEF routed.
* Some bug fixed.

v1.4
---------
* Now you can create a quotes list by category.

v1.3
---------
* Added search options ( You can search by author and phrase )
* Changed inline style to CSS classes

v1.2
---------
* Added search form
* Added several options

