Vip Quotes for Joomla! 
==========================
( Version 2.3 )
--------------------------

Changelog
---------

v2.3
---------

* Added Search Plugin
* Improved Vip Last Quotes Module
* Improved Vip Random Quotes Module
* Improved SEO
* Fixed some issues 


v2.2
---------
* Added fron-end interface for adding quotes
* Added new views - a list with auhtors' quotes, a quote view
* Added authors
* Added new options - ordering, security, 
* Improved



